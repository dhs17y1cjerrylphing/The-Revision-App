# TRA

This app is based on the client template found at buildingblocs/vuetify-todo-app. Major thanks to ThePyProgrammer for setting the template up

This template dictates an application powered based on public APIs (including GitHub's API). A demonstration of a sample Flask App to work with this App will also be added soon.

Anyways, please do use this to understand how to use Vue to access APIs and style and all that.


## Project setup
```
npm install
```
or simply
```
npm i
```

### How to run the application locally
```
npm run serve
```

### Compiles and minifies for production (to ~~unreadable~~ HTML/CSS/JS)
```
npm run build
```

### Lints and fixes files
```
npm run lint
```

^ For this, you should simply try to use Visual Studio Code with the Lint plugins (Likely with Vetur).
