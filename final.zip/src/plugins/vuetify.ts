import Vue from "vue";
import Vuetify from "vuetify";

// (Optional) import 'vuetify-datetime-picker/src/stylus/main.styl'

Vue.use(Vuetify);

export default new Vuetify({});
